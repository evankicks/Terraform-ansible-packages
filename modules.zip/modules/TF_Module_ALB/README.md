# TF_Module_ALB

### Description
A simple module to create an ALB.

-----
## Module Input Variables
- `vpc_id` - VPC ID for the security group; subnets_private MUST also be associated with same vpc. Default: N/A
- `is_public` - is it a public facing ELB. Set to 1. Default: `1`
- `open_80` - A boolean, 1 or 0, value to turn on or off port 80 listener. Default: `1`
- `alb_port80_response_type` - The default action response type. Can be fixed-response, redirect, or forward. Default: `forward`
- `alb_port80_redirect_port` - The port to redirect to if response type is redirect. Default: `443`
- `alb_port80_redirect_protocol` - The protocol to use in redirect if response type is redirect. Default: `HTTPS`
- `alb_port80_fixed_status_code` - The status code to return when response type is fixed-response. Default: `401`

- `open_443` - A boolean, 1 or 0, value to turn on or off port 443 listener. Default: `1`
- `alb_port443_response_type` - The default action response type. Can be fixed-response, redirect, or forward. Default: `forward`
- `alb_port443_redirect_port` - The port to redirect to if response type is redirect. Default: `443`
- `alb_port443_fixed_status_code` - The status code to return when response type is fixed-response. Default: `401`

- `alb_port80_cidr_block` - A list of cidr blocks to permit for the ALB port 80 listener. Default: `["0.0.0.0/0"]`
- `alb_port443_cidr_block` - A list of cidr blocks to permit for the ALB port 80 listener. Default: `["0.0.0.0/0"]`
- `alb_subnets` - A list of subnets, typically public subnets for is_public = 1. Default: N/A
- `alb_idle_timeout` - The time in seconds that the connection is allowed to be idle Default: `60`
- `alb_access_logs_bucket_name` - S3 bucket where log is kept. Default: N/A
- `alb_access_logs_bucket_prefix` - The S3 bucket prefix. Default: `""`

- `alb_ssl_cert_iam_id` - The arn of an SSL certificate to use on port 443. Default: N/A
- `alb_ssl_policy` - The SSL Certificate Policy for port 443. Default: `ELBSecurityPolicy-2016-08`
- `app_port` - Port where the application is listening. Default: N/A
- `alb_health_check_protocol` - Health Check Protocol. Default: `HTTP`
- `alb_health_check_interval` - Health Check Frequency. Default: `10`
- `alb_healthy_threshold` - Number of checks before the instance is declared healthy. Default: `2`
- `alb_unhealthy_threshold` - Number of checks before the instance is decleard unhealthy. Default: `3`
- `alb_health_check` - Health Check URI. Default: N/A
- `alb_health_check_timeout` - The length of time before check is declared time out. Default: `5`
- `alb_instances` - A list of instances to target for this ALB. Default: N/A
- `alb_instances_count` - The number of instances in the list of instances. Default: N/A

- `tag_service` - Service Name such as prm; it is used to construct Name tag. Default: N/A
- `tag_role` - Instance Role such as hpx,was; it is used to construct Name tag. Default: N/A
- `tag_project` - A project identifier used in tags. Default: `kpgw`
- `tag_environment` - The environment identifier. Default: `preprod`
- `tag_primary_owner` - The primary owner tag. Default: `Primary Owner`
- `tag_secondary_owner` - The secondary owner tag. Default: `Second Owner`
- `tag_timeframe` - The timeframe tag. Default: `7x24`

-----
## Usage
```
module "TF_Module_ALB" {
  source = "git::https://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_ALB"

  vpc_id                 = "${var.vpc_id}"
  alb_port80_cidr_block  = ["${var.alb_port80_cidr_block}"]
  alb_port443_cidr_block = ["${var.alb_port443_cidr_block}"]
  alb_subnets            = ["${var.alb_subnets}"]

  alb_access_logs_bucket_name   = "${var.alb_access_logs_bucket_name}"
  alb_access_logs_bucket_prefix = "${var.alb_access_logs_bucket_prefix}"
  alb_ssl_cert_iam_id           = "${var.alb_ssl_cert_iam_id}"
  app_port                      = "${var.app_port}"
  alb_health_check              = "${var.alb_health_check}"
  alb_instances                 = ["${var.alb_instances}"]

  tag_service = "${var.tag_service}"
  tag_role    = "${var.role}"
}
```

-----
## Module Output Variables
- `alb_id`               - Application Load Balancer ID
- `alb_name`             - Application Load Balancer Name
- `alb_dns_name`         - Cache Server instance addresses
- `alb_zone_id`          - ALB Availability Zones
- `alb_sg_id`            - ALB Security Group ID
- `alb_sg_name`          - ALB Security Group Name
- `alb_listener_arn`     - ALB Listener ARN for the port 443 listener.
- `alb_target_group_arn` - ALB Target Group ARN
