#!/bin/sh
# change ssh port
sudo bash -c 'echo -e "\nPort 422" >> /etc/ssh/sshd_config'
sudo bash -c 'echo -e "\nPort 22" >> /etc/ssh/sshd_config'
sudo /etc/init.d/sshd restart