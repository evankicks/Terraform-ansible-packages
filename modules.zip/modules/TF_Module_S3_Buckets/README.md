# TF_Module_S3_Buckets

### Description
A small terraform module to create s3 buckets with their IAM policy, if required.
All s3 buckets are created for the region.

-----
## Module Input Variables
- `aws_region` - The AWS Region where the s3 bucket resides. Default: N/A
- `s3_account_id` - The AWS account ID which is used for IAM policy. Default: `841007833247`
- `s3_environment` - The environment tag for s3 buckets. When left as "", will not create environment specific s3 buckets. Default: `""`
- `s3_profile` - The profile tag for s3 buckets. Default: `kpgw`
- `s3_cloudtrail_namespace` - The suffix for cloudtrail's s3 bucket name. Default: `cloudtrail-logs`
- `s3_elb_log_accounts` - A reference map for AWS default accounts to permit AWS ELB access logs. Default: multiple
- `s3_kpgw_replica_bucket` - The AWS S3 bucket arn for replicating data from KPGW-<env> bucket. Default: `""`
- `s3_kpgw_replica_bucket_prefix` - The prefix to use in the KPGW-<env> replica bucket. Default: `default`
- `s3_gw_elk_backup_replica_bucket` - The AWS S3 bucket arn for replicating data from gw-elk-backup bucket. Default: `""`
- `s3_gw_elk_backup_replica_bucket` - The prefix to use in the gw-elk-backup replica bucket. Default: `default`


-----
## Usages
```
module "TF_Module_S3_Buckets" {
  source = "git::https://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_S3_Buckets"

  aws_region              = "${var.aws_region}"
  s3_environment          = "${var.environment}"
  s3_profile              = "${var.profile}"
  s3_cloudtrail_namespace = "${var.s3_cloudtrail_namespace}"

}
```

-----
## Module Output Variables
- `elk_backup_id` - ELK Backup s3 bucket ID.
- `elk_backup_arn` - ELK Backup s3 bucket ARN.
- `cloudtrail_bucket_id` - Cloudtrail s3 bucket ID.
- `cloudtrail_bucket_arn` - Cloudtrail s3 bucket ARN.
