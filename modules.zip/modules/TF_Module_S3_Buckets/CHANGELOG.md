## 1.1.0 (December 12, 2018)
NEW FEATURES:
 * Replaced the default account ID in favor of the dev account.
 * Added count conditionals for account specific buckets.
 
## 1.0.0 (Unreleased)

## 0.0.1 (August 21, 2018)
NEW FEATURES:
IMPROVEMENTS:
BUG FIXES:
