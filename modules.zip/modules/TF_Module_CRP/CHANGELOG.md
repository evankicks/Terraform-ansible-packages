
## 1.0.0 (December 17, 2018)
IMPROVEMENTS:
 * Locked down the use of the TF_Module_EC2 to v2_3.

## 0.0.1 (August 21, 2018)
NEW FEATURES:
IMPROVEMENTS:
BUG FIXES:
