# TF_Module_CRP

### Description
A module to set up batch hosts, Web front end servers and services, and a redis cluster.

-----
## Module Input Variables
- `crp_project` - The project tag for CRP. Default: N/A
- `crp_environment` - The environment tag for CRP. Default: N/A
- `crp_service` - The service tag for CRP. Default: `crp`
- `crp_role` - The role tag for CRP. Default: `was`
- `crp_elb_role` - The role tag for CRP's external ELB. Default: `web`
- `crp_batch_role` - The role tag for CRP's batch EC2. Default: `bat`
- `crp_primary_owner` - The primary owner tag. Default: N/A
- `crp_secondary_owner` - The secondary owner tag. Default: N/A
- `crp_redis_primary_owner` - The primary owner tag for Redis. Default: `kl.cheng@partner.samsung.com`
- `crp_redis_second_owner` - The second owner tag for Redis. Default: `nobody`
- `crp_was_vpc_zone_aliases` - The VPC Zone Aliases tag. Default: N/A

- `crp_vpc_id` - The VPC ID to put crp instances in. Default: N/A
- `crp_vpc_cidr_block` - The VPC CIDR block, used in the Redis cluster declaration. Default: N/A

- `crp_was_ami` - The AMI ID for the WAS instances. Default: `ami-0cc98489b9c201694`
- `crp_was_instance_type` - The Instance Type for the WAS instances. Default: `t2.micro`
- `crp_was_key_pair` - The name of the EC2 Key Pair for WAS instances. Default: N/A
- `crp_was_subnet_ids` - The subnet IDs for the WAS instances. Default: N/A
- `crp_was_common_sg_id` - A security group for WAS instances to open common ports. Default: N/A
- `crp_was_user_data` - A file for loading WAS cloud-init data. Default: N/A

- `crp_was_timeframe` - The time_frame tag attached to was security group. Default: `7X24`

- `crp_redis_cluster_name` - The cluster name for CRP's redis cluster. Default: `crp-cache`
- `crp_availability_zones` - The availability zones for CRP's redis cluster. Default: N/A

- `crp_app_port` - CardiacRehab application listening port Default: `8080`
- `crp_elb_cert_iam_id` - SSL Certificate IAM ID Default: `arn:aws:acm:us-east-1:060671536724:certificate/4a3bca39-0f19-469f-b1dd-87595d091dbf`
- `crp_elb_health_check` - ELB Health Check URL Default: `/cardiacrehab-v2/r1/test/alive`
- `crp_elb_health_check_protocol` - ELB Health Check Protocol Default: `HTTP`
- `crp_elb_healthy_threshold` - ELB Health Check threshold for healthy. Default: `3`
- `crp_elb_unhealthy_threshold` - ELB Health Check threshold for unhealthy. Default: `2`
- `crp_elb_health_check_timeout` - ELB Health Check timeout for health checks. Default: `5`
- `crp_elb_logs_bucket_name` - S3 bucket where access log is stored. Default: `kpgw-preprod`

- `crp_batch_nodes` - The number of CRP Batch hosts. Default: `1`

-----
## Usage
```
module "TF_Module_CRP" {
  source = "git::https://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_CRP"

  crp_project              = "${var.project}"
  crp_environment          = "${var.environment}"
  crp_service              = "${var.service}"
  crp_role                 = "${var.crp_role}"
  crp_elb_role             = "${var.crp_elb_role}"
  crp_batch_role           = "${var.crp_batch_role}"
  crp_primary_owner        = "${var.crp_primary_owner}"
  crp_secondary_owner      = "${var.crp_secondary_owner}"
  crp_redis_primary_owner  = "${var.crp_redis_primary_owner}"
  crp_redis_second_owner   = "${var.crp_redis_second_owner}"
  crp_was_vpc_zone_aliases = "${module.TF_Module_VPC.vpc_zone_aliases}"

  crp_vpc_id         = "${module.TF_Module_VPC.vpc_id}"
  crp_vpc_cidr_block = "${module.TF_Module_VPC.vpc_cidr_block}"

  crp_was_ami           = "${var.crp_was_ami}"
  crp_was_instance_type = "${var.crp_was_instance_type}"
  crp_was_key_pair      = "${var.crp_was_key_pair}"
  crp_was_subnet_ids    = "${module.TF_Module_VPC.vpc_private_subnet_ids}"
  crp_was_common_sg_id  = "${module.TF_Module_VPC.vpc_common_sg_id}"
  crp_was_user_data     = "${var.crp_was_user_data}"

  crp_was_timeframe = "${var.crp_was_timeframe}"

  crp_redis_cluster_name = "${var.crp_redis_cluster_name}"
  crp_availability_zones = "${module.TF_Module_VPC.vpc_availability_zones}"

  crp_app_port                  = "${var.crp_app_port}"
  crp_elb_cert_iam_id           = "${var.crp_elb_cert_iam_id}"
  crp_elb_health_check          = "${var.crp_elb_health_check}"
  crp_elb_health_check_protocol = "${var.crp_elb_health_check_protocol}"
  crp_elb_healthy_threshold     = "${var.crp_elb_healthy_threshold}"
  crp_elb_unhealthy_threshold   = "${var.crp_elb_unhealthy_threshold}"
  crp_elb_healthy_check_timeout = "${var.crp_elb_health_check_timeout}"
  crp_elb_logs_bucket_name      = "${var.crp_elb_logs_bucket_name}"

  crp_batch_nodes = "${var.crp_batch_nodes}"

}
```

-----
## Module Output Variables
- `crp_was_sg_id` - CRP's WAS Security Group ID, which is used in the Phoenix security group rule of the EMR module.
- `crp_was_sg_name` - CRP's WAS Security Group Name.
