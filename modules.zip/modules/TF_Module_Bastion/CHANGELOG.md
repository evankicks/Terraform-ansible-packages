## 1.1.1 (January 9, 2019)
NEW FEATURES:
  * Default ssh port of 422.
  * Added tags SEC_ASSETS (bastion_tag_sec_assets) and SEC_ASSETS_GATEWAY (bastion_tag_sec_assets_gateway)
  * Locked to EC2 modules v2_3_1 tag.
  
## 1.1.0 (October 23, 2018)
NEW FEATURES:
  * Added two output variables, bastion_sg_id and bastion_sg_name.
  
## 1.0.0 (Unreleased)

## 0.0.1 (August 21, 2018)
NEW FEATURES:
IMPROVEMENTS:
BUG FIXES:
