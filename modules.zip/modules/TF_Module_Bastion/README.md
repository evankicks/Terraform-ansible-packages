# TF_Module_Bastion

### Description
Create a bastion host for a VPC.

-----
## Module Input Variables
- `bastion_qty` - The number of bastion hosts to deploy. Default: `1`
- `bastion_ami` - The Bastion host AMI. Default: `ami-038c425781c6958e7`
- `bastion_instance_type` - The instance type for the bastion host. Default: `t2.micro`
- `bastion_key_pair` - The ec2 key pair to use for the bastion host. Default: N/A
- `bastion_user_data` - The file name for the bastion user data. Default: N/A
- `bastion_public_subnets_ids` - A list of subnet IDs to put the bastion host in. Typically, these are the public subnets. Default: N/A
- `bastion_with_public_ip` - A one to create the bastion host with a public IP address (or not). Default: `1`
- `bastion_security_group_ids` - A list of security groups to associate with the bastion host. Default: N/A
- `bastion_tag_project` - A tag that is associated with both the project and service tags on the bastion host. Default: N/A
- `bastion_tag_environment` - The tag for the environment. Default: N/A
- `bastion_tag_role` - The tag for the role. Default: N/A
- `bastion_tag_zones` - The tag for the zones. Default: N/A
- `bastion_tag_purpose` - The tag for purpose. Default: `ssh`
- `bastion_tag_timeframe` - The timeframe tag. Default: N/A
- `bastion_tag_first_owner` - The first owner tag. Default: N/A
- `bastion_tag_second_owner` - The second owner tag. Default: N/A
- `bastion_ports` - A list of TCP ports associated with the bastion host, typically just ssh. Default: `22`
- `bastion_ingress_ips` - A list of CIDR blocks to permit access to the bastion host. Default: N/A
- `bastion_vpc_id` - The ID of the bastion's VPC. Default: N/A
- `bastion_iam_role` - The IAM Role associated with the instance. Default: `EC2_General`

-----
## Usage
```
module "bastion_host" {
  source = "git::ssh://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_Bastion"

  bastion_ami           = "${var.bastion_ami}"
  bastion_instance_type = "${var.bastion_instance_type}"
  bastion_key_pair      = "${var.bastion_key_pair}"
  bastion_user_data     = "${var.bastion_user_data}"

  bastion_vpc_id             = "${var.bastion_vpc_id}"
  bastion_public_subnets_ids = ["${var.bastion_public_subnets_ids}"]
  bastion_security_group_ids = ["${var.bastion_security_group_ids}"]
  bastion_ingress_ips        = ["${var.bastion_ingress_ips}"]

  bastion_tag_project      = "${var.bastion_tag_project}"
  bastion_tag_environment  = "${var.bastion_tag_environment}"
  bastion_tag_role         = "${var.bastion_tag_role}"
  bastion_tag_zones        = "${var.bastion_tag_zones}"
  bastion_tag_timeframe    = "${var.bastion_tag_timeframe}"
  bastion_tag_first_owner  = "${var.bastion_tag_first_owner}"
  bastion_tag_second_owner = "${var.bastion_tag_second_owner}"

}
```

-----
## Module Output Variables
- `bastion_sg_id` - The bastion security group id.
- `bastion_sg_name` - The bastion security group name.
