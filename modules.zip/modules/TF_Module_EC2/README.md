# TF_Module_EC2

### Description
A simple module to create 1 or more EC2 instances.
-----
## Module Input Variables
- `nodes_qty` - Number of EC2 instances to create. Default: `2`
- `ami` - The AMI ID to create the EC2 instances from. Default: N/A
- `instance_type` - The EC2 instance type. Default: `t2.medium`
- `enable_detailed_monitoring` - Set to 1 to enable detailed cloudwatch monitoring. Default: `0`
- `subnet_ids` - A list of subnet IDs to create the EC2s in. Default: N/A
- `ec2_user_data` - The user data, which is a series of commands to run at launch or reboot. Default: N/A
- `has_public_ip` - Set to 1 to create the instance(s) with a public IP address. Default: `0`

- `aws_key_pair_name` -
- `ec2_sg_list` - A list of security groups IDs to associate with
- `ebs_optimized` - If true, the launched EC2 instance will be EBS-optimized. Default: false
- `iam_instance_profile` - The IAM Role for the instance(s). Default: `EC2_General`


- `tag_service` - Service Name such as prm; Used in the construction of the Name tag. Default: N/A
- `tag_role` - Instance Role such as hpx,was; it is used to contruct Name tag. Default: N/A
- `tag_purpose` - The value for the purpose tag. Default: N/A
- `tag_project` - The value for the project tag. Default: N/A
- `tag_environment` - The value for the environment tag. Default: N/A
- `tag_timeframe` - The value for the timeframe tag. Default: `7x24`
- `tag_configured` - The value for the configured tag. Default: `ansible`
- `tag_first_owner` - The value for the first owner tag. Default: `A. Doe`
- `tag_second_owner` - The value for the second owner tag. Default: `A. Doe`
- `tag_purpose_ec2` - The value for the purpose ec2 tag. Default: `""`
- `tag_zones` - Alias names of Availability Zones. Default: N/A

-----
## Usage
```
module "TF_Module_EC2" {
  source = "git::https://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_EC2"

  nodes_qty                  = "${var.number_of_nodes}"
  ami                        = "${var.AmazonMachineImage}"
  instance_type              = "${var.instance_type}"
  enable_detailed_monitoring = "${var.zero_or_one}"
  subnet_ids                 = ["${var.public_or_private_subnet_ids}"]
  ec2_user_data              = "${var.cloud_init}"
  has_public_ip              = "${var.zero_or_one}"
  aws_key_pair_name          = "${var.ec2_key_pair}"
  ec2_sg_list                = "${var.ec2_security_groups_ids}"
  ebs_optimized              = "${var.true_or_false}"
  iam_instance_profile       = "${var.iam_instance_profile}"

  tag_service      = "${var.tag_service}"
  tag_role         = "${var.tag_role}"
  tag_purpose      = "${var.tag_purpose}"
  tag_purpose_ec2  = "${var.tag_purpose_ec2}"
  tag_project      = "${var.tag_project}"
  tag_environment  = "${var.tag_environment}"
  tag_timeframe    = "${var.tag_timeframe}"
  tag_configured   = "${var.tag_configured}"
  tag_first_owner  = "${var.NumeroUno}"
  tag_second_owner = "${var.NumberTwo}"
  tag_zones        = "${var.tag_zones}"

}
```

-----
## Module Output Variables
- `ec2_instance_ids` - A list of EC2 instance IDs.
- `ec2_instance_private_ips` - A list of private IPs for the EC2 instances.
- `ec2_instance_private_dns` - A list of private DNS names for the EC2 instances.
- `ec2_instance_subnet_ids` - A list of subnet IDs for the EC2 instances.
- `ec2_instance_public_dns` - A list of public DNS for the EC2 instances.
- `ec2_instance_public_ips` - A list of public IPs for the EC2 instances.
- `ec2_instance_availability_zones` - A list of instance availability zones.
- `ec2_route53_fqdn` - A list of fully qualified domain names for each of the instances.
