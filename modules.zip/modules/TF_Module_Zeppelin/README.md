# TF_Module_Zeppelin

### Description
A module to create the zeppelin web server, attached EBS volumes, and create an ELB.

-----
## Module Input Variables
- `zeppelin_account_id` - The account id, which is used in the KMS policy. Default: 060671536724
- `zeppelin_project` - The project name and tag value. Default: N/A
- `zeppelin_environment` - The environment tag. Default: N/A
- `zeppelin_s3_bucket_name` - The s3 bucket to use for zeppelin logs. Default: N/A
- `zeppelin_service` - The service tag. Default: N/A
- `zeppelin_primary_owner` - The primary owner for zeppelin instances and ELB. Default: N/A
- `zeppelin_secondary_owner` - The secondary owner for zeppelin instance and ELB. Default: N/A
- `zeppelin_timeframe` - The timeframe tag value for the zeppelin master servers. Default: `7X24`
- `zeppelin_vpc_id` - The VPC ID for the zeppelin server. Default: N/A
- `zeppelin_vpc_public_subnet_ids` - The subnet IDs for the zeppelin ELB, typically from a public subnet. Default: N/A
- `zeppelin_vpc_private_subnet_ids` - The subnet IDs for the zeppelin instances, typically from a private subnet. Default: N/A
- `zeppelin_vpc_common_sg_id` - A common security group ID for ssh access. Default: N/A
- `zeppelin_emr_private_master_sg_id` - A security group ID for EMR Private Master. Default: N/A
- `zeppelin_master_ec2_user_data` - The filename for the zeppelin master server user data. Default: `../cloud-init/zeppelin-cloud-init`
- `zeppelin_iam_profile` - The IAM profile to use for the instances. Default: `EC2_General`
- `zeppelin_root_volume_size` - The root volume size for the zeppelin instances. Default: `100`
- `zeppelin_master_ebs_volume_size` - The Master instance's EBS volume size. Default: `80`
- `zeppelin_data1_ebs_volume_size` - The first data EBS volume size. Default: `80`
- `zeppelin_data2_ebs_volume_size` - The second data EBS volume size. Default: `80`
- `zeppelin_availability_zone` - The availability zone. Default: N/A
- `zeppelin_ami` - The AMI to use for Zeppelin instances. Default: `ami-d54a5bb5`
- `zeppelin_instance_type` - The Instance Type for Zeppelin instances. Default: `r3.large`
- `zeppelin_key_pair` - The EC2 keypair to use for the Zeppelin servers. Default: N/A
- `zeppelin_elb_logs_bucket_name` - The s3 bucket for Zeppelin ELB logs. Default: N/A
- `zeppelin_elb_certificate_id` - The SSL certificate ID associated with the Zeppelin ELB. Default: N/A
- `zeppelin_elb_healthy_threshold` - The ELB Health Check threshold for healthy. Default: `3`
- `zeppelin_elb_unhealthy_threshold` - The ELB Health Check threshold for unhealthy. Default: `2`
- `zeppelin_elb_health_check_protocol` - The ELB Health Check Protocol. Default: `HTTP`
- `zeppelin_elb_health_check_timeout` - The ELB Health Check timeout for health checks. Default: `5`
- `zeppelin_elb_port` - The ELB inbound port. Default: `8080`
- `zeppelin_elb_health_check` - The ELB Health Check target. Default: `/#/login`
- `zeppelin_lb_sg_cidr_block` - The CIDR block to permit ingress on zeppelin's load balancers. Default: `["0.0.0.0/0"]`
- `zeppelin_internal_hosted_zone_id` - The zone ID for a route 53 private hosted zone. Default: N/A

-----
## Usage
```
module "TF_Module_Zeppelin" {
  source = "git::https://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_Zeppelin"

  zeppelin_project = "${var.project}"
  zeppelin_environment = "${var.environment}"
  zeppelin_s3_bucket_name = "${var.zeppelin_s3_bucket_name}"
  zeppelin_service = "${var.service}"
  zeppelin_primary_owner = "${var.zeppelin_primary_owner}"
  zeppelin_secondary_owner = "${var.zeppelin_secondary_owner}"

  zeppelin_vpc_id = "${module.TF_Module_VPC.vpc_id}"
  zeppelin_vpc_public_subnet_ids = "${module.TF_Module_VPC.vpc_public_subnet_ids}"
  zeppelin_vpc_private_subnet_ids = "${module.TF_Module_VPC.vpc_private_subnet_ids}"
  zeppelin_vpc_common_sg_id = "${module.TF_Module_VPC.vpc_common_sg_id}"
  zeppelin_emr_private_master_sg_id = "${module.TF_Module_EMR.emr_private_master_sg_id}"

  zeppelin_availability_zone = "${module.TF_Module_VPC.vpc_availability_zones}"
  zeppelin_key_pair = "${var.zeppelin_key_pair}"
  zeppelin_elb_logs_bucket_name = "${join("-",list(var.project, var.environment))}"
  zeppelin_elb_certificate_id = "${var.zeppelin_elb_certificate_id}"
  zeppelin_internal_hosted_zone_id = "${var.zeppelin_internal_hosted_zone_id}"
}
```

-----
## Module Output Variables
- `zeppelin_sg_id` - The Zeppelin security group ID.
- `zeppelin_sg_name` - The Zeppelin security group name.
