module-vpc terraform module
===========

A terraform module to provide a VPC in AWS.


Module Input Variables
----------------------

- `vpc_cidr` - vpc cidr
- `public_subnets` - list of public subnet cidrs
- `private_subnets` - list of private subnet cidrs
- `haproxy_subnets` - list of private haproxy subnet cidrs
- `database_subnets` - list of database subnet CIDRs.
- `azs` - list of AZs in which to distribute subnets
- `enable_dns_hostnames` - should be true if you want to use private DNS within the VPC
- `enable_dns_support` - should be true if you want to use private DNS within the VPC
- `enable_nat_gateway` - should be true if you want to provision NAT Gateways
- `map_public_ip_on_launch` - should be false if you do not want to auto-assign public IP on launch
- `private_propagating_vgws` - list of VGWs the private route table should propagate
- `public_propagating_vgws` - list of VGWs the public route table should propagate
- `tag_project` - name of this project / VPC
- `tag_environment` - environment name such as preprod
- `ssh_port` - The ssh port to use for the default security group for this VPC. Default is 22.

It's generally preferable to keep `public_subnets`, `private_subnets`, and
`azs` to lists of the same length.

This module optionally creates NAT Gateways (one per availability zone) and sets them
as the default gateways for the corresponding private subnets.

Usage
-----

```hcl
module "vpc" {
  source = "github.com/.../module-vpc"

  tag_project     = "my-project-name"
  tag_environment = "my-env"

  vpc_cidr = "10.0.0.0/16"
  private_subnets = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
  public_subnets  = ["10.0.101.0/24", "10.0.102.0/24", "10.0.103.0/24"]

  enable_nat_gateway = "true"

  azs      = ["us-west-2a", "us-west-2b", "us-west-2c"]

}
```

For Terraform version older than 0.9.0 use `ref=v0.1.0`:
`source = "github.com/terraform-community-modules/module-vpc?ref=v1.0.0"`

Outputs
=======

 - `vpc_id` - does what it says on the tin
 - `vpc_azs` - list of Availablility Zone
 - `vpc_cidr_block` - VPC CIDR
 - `private_subnets_ids` - list of private subnet ids
 - `public_subnets_ids` - list of public subnet ids
 - `haproxy_subnets_ids` - list of haproxy subnets ids
 - `database_subnets_ids` - list of database subnets ids
 - `public_route_table_ids` - list of public route table ids
 - `private_route_table_ids` - list of private route table ids
 - `haproxy_route_table_ids` - list of haproxy route table ids
 - `database_route_table_ids` - list of database route table ids
 - `default_security_group_id` - VPC default security group id string
 - `nat_eips` - list of Elastic IP ids (if any are provisioned)
 - `nat_eips_public_ips` - list of NAT gateways' public Elastic IP's (if any are provisioned)
 - `natgw_ids` - list of NAT gateway ids
 - `igw_id` - Internet Gateway id string
 - `bastion_security_group_id` - default bastion security group id
 - `bastion_security_group_name` - default bastion security group name
 - `r53_internal_zone_id` - internal host zone for ec2 custom hostnmae
 - `r53_internal_zone_ns` - internal host zone name service
 - `r53_internal_zone_domain` - internal host zone domain name

**NOTE**: previous versions of this module returned a single string as a route
table ID, while this version returns a list.

Authors
=======

Originally created and maintained by [Casey Ransom](https://github.com/cransom)
Hijacked by Kwan Cheng

License
=======

Apache 2 Licensed. See LICENSE for full details.
