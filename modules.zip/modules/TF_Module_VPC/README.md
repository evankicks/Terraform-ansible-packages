# TF_Module_VPC

### Description
A simple module for creating a VPC with public, private, and haproxy subnets. Options given to enable DNS support and NAT gateways.

-----
## Module Input Variables

- `vpc_cidr`              - The CIDR range for this VPC. Default: N/A
- `vpc_public_subnets`    - A list of CIDR ranges for the public subnets. Default: N/A
- `vpc_private_subnets`   - A list of CIDR ranges for the private subnets. Default: N/A
- `vpc_haproxy_subnets`   - A list of CIDR ranges for the haproxy subnets. Default: N/A
- `vpc_database_subnets`  - A list of CIDR ranges for the database subnets. Default: N/A
- `vpc_availabilityzones` - A list of AWS availability zone to build the VPC in. Default: N/A
- `vpc_ssh_port`          - The SSH port number. Default: `22`
- `vpc_tag_project`       - A value for the project tag. Default: N/A
- `vpc_tag_environment`   - A value for the environment tag. Default: N/A

- `vpc_enable_dns_support`   - Turns on/off DNS support in the VPC. Default: `true`
- `vpc_enable_dns_hostnames` - Turns on/off DNS hostnames in the VPC. Default: `true`
- `vpc_enable_nat_gateway`   - Turns on/off NAT gateway in the VPC. Default: `true`
- `vpc_sg_common_prefix`     - Adds a string component to the name of the common security group for ssh connections on EC2 instances. Default: `""`

-----
## Usage
```
module "TF_Module_VPC" {
  source = "git::https://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_VPC"

  vpc_cidr              = "${var.vpc_cidr_preprod}"
  vpc_public_subnets    = "${var.vpc_public_subnets_preprod}"
  vpc_private_subnets   = "${var.vpc_private_subnets_preprod}"
  vpc_haproxy_subnets   = "${var.vpc_haproxy_subnets_preprod}"
  vpc_availabilityzones = "${var.vpc_availabilityzones_preprod}"

  vpc_tag_project     = "${var.project}"
  vpc_tag_environment = "${var.environment}"
}
```

-----
## Module Output Variables
- `vpc_id`           - The VPC ID.
- `vpc_zone_aliases` - A list of Zone aliases for this VPC.
- `vpc_cidr_block`   - The CIDR block of this VPC.
- `vpc_private_subnet_ids` - A list of private subnet IDs.
- `vpc_public_subnet_ids` - A list of public subnet IDs.
- `vpc_haproxy_subnet_ids` - A list of haproxy subnet IDs.
- `vpc_database_subnet_ids` - A list of database subnet IDs.
- `vpc_igw_id` - The internet gateway ID.
- `vpc_nat_eips` - A list of IDs for NAT Gateway elastic IPs.
- `vpc_nat_eips_public_ips` - A list of elastic IPs for NAT gateway public.
- `vpc_natgw_ids` - A list of NAT Gateway IDs.
- `vpc_internal_zone_id` - The Route53 internal zone ID.
- `vpc_internal_zone_ns` - The Route53 internal zone Name Servers.
- `vpc_availability_zones` - The VPC Availability Zones.
