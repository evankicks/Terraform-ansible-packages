# TF_Module_EMR

### Description

Cyclic problem solved with help of revoke rules on delete

The module creates and deploys two EMR clusters in one VPC, an HBase and a Spark cluster.

-----
## Module Input Variables
- `emr_aws_profile` - The AWS Profile to use when executing the local python scripts. Default: N/A
- `emr_vpc_id` - The VPC ID for the EMR cluster. Default: N/A
- `emr_account_id` - The account id, which is used in the KMS policy. Default: 060671536724
- `emr_cidr_block` - The CIDR Block for the EMR cluster. Default: N/A
- `emr_azone` - The availability zone for the EMR cluster. Default: N/A
- `emr_nat_gateway_id` - The NAT Gateway ID for the EMR cluster. Default: N/A
- `emr_was_sg_id` - The WAS Security Group ID for the phoenix security group rule. Default: ""
- `emr_tag_service` - The service tag. Default: "EMR"
- `emr_tag_role` - The role tag. Default: N/A
- `emr_tag_environment` - The environment tag. Default: N/A
- `emr_tag_first_owner` - The first owner tag. Default: N/A
- `emr_tag_second_owner` - The second owner tag. Default: N/A
- `emr_tag_project` - The project tag. Default: N/A
- `emr_route53_hosted_zone` - A route53 hosted zone ID to use for creating internal DNS names of the EMR instances. Default: `""`
- `emr_route53_create_entries` - A boolean value (0 for false, 1 for true) to create route53 record entries for all of the EMR instances. Default: `0`.
- `emr_bastion_sg_id` - The bastion security group ID that is used to open ports 16030 (core) and 16010 (master) from the bastion host. Default: N/A

-----
Variables for HBase EMR cluster.
-----
- `emr_hbase_name` - The name of the HBase EMR cluster. Default: "gw-hbase"
- `emr_hbase_release_label` - The AWS EMR release version for HBase. Default: "emr-5.7.0"
- `emr_hbase_service_role` - HBase cluster's service role. Default: "EMR_DefaultRole"
- `emr_hbase_iam_role` - HBase cluster's IAM role. Default: "EMR_EC2EMR_DefaultRole"
- `emr_hbase_applications` - HBase cluster's list of applications. Default: ["Hadoop","Phoenix"]
- `emr_hbase_log_uri` - HBase cluster's log uri. Default: N/A
- `emr_hbase_master_instance_type` - The instance type for the master instances of the HBase cluster. Default: "c4.2xlarge"
- `emr_hbase_core_instance_type` - The instance type for the core instances of the HBase cluster. Default: "c4.2xlarge"
- `emr_hbase_core_instance_count` - The number of core instances in the HBase cluster. Default: "3"
- `emr_hbase_sg_id` - The security group id for HBase EMR instances. Default: N/A
- `emr_hbase_bootstrap_path` - The location of the bootstrap script for the EMR HBase. Default: N/A
- `emr_hbase_root_volume_size` - The size in GB of the root EBS volume attached to the HBase EMR Cluster. Default: "32"
- `emr_hbase_ebs_volume_size` - The size in GB of the EBS volumes attached to the HBase master and core instances. Default: "32"
-----
Variables for Spark EMR cluster.
-----
- `emr_spark_name` - The name of the Spark EMR cluster. Default: "gw-spark"
- `emr_spark_release_label` - The AWS EMR release version for Spark. Default: "emr-5.7.0"
- `emr_spark_service_role` - Spark cluster's service role. Default: "EMR_DefaultRole"
- `emr_spark_applications` - Spark cluster's list of applications. Default: ["Hadoop", "Ganglia", "Spark", "Hue"]
- `emr_spark_log_uri` - Spark cluster's log uri. Default: N/A
- `emr_spark_master_instance_type` - The instance type for the master instances of the Spark cluster. Default: "m4.large"
- `emr_spark_core_instance_type` - The instance type for the core instances of the Spark cluster. Default: "m4.large"
- `emr_spark_core_instance_count` - The number of core instances in the Spark cluster. Default: "3"
- `emr_spark_sg_id` - The security group id for Spark EMR instances. Default: N/A
- `emr_spark_iam_role` - Spark cluster's IAM role. Default: "EMR_EC2_DefaultRole"
- `emr_spark_config_file` - Spark cluster's JSON configuration file. Default: "../conf/spark-conf.json"
- `emr_spark_bootstrap_path` - The location of the bootstrap script for the EMR Spark. Default: N/A
- `emr_spark_root_volume_size` - The size in GB of the root EBS volume attached to the Spark EMR Cluster. Default: "32"
- `emr_spark_ebs_volume_size` - The size in GB of the EBS volumes attached to the Spark master and core instances. Default: "32"


-----
## Usage
```
module "TF_Module_EMR" {
  source = "git::https://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_EMR"

  emr_vpc_id           = "${module.TF_Module_VPC.vpc.id}"
  emr_cidr_block       = "${module.TF_Module_VPC.vpc_cidr_block}"
  emr_azone            = "${module.TF_Module_VPC.vpc_availability_zone}"
  emr_nat_gateway_id   = "${module.TF_Module_VPC.nat_gw_ids}"
  emr_was_sg_id        = "${var.emr_was_sg_id}"
  emr_tag_service      = "${var.emr_tag_service}"
  emr_tag_role         = "${var.emr_tag_role}"
  emr_tag_environment  = "${var.environment}"
  emr_tag_first_owner  = "${var.first_owner}"
  emr_tag_second_owner = "${var.second_owner}"
  emr_tag_project      = "${var.project}"

  emr_hbase_name           = "${var.emr_hbase_name}"
  emr_hbase_log_uri        = "${var.emr_hbase_log_uri}"
  emr_hbase_sg_id          = "${module.TF_Module_VPC.vpc_common_sg_id}"
  emr_hbase_bootstrap_path = "${var.emr_hbase_bootstrap_path}"

  emr_spark_name           = "${var.emr_spark_name}"
  emr_spark_log_uri        = "${var.emr_spark_log_uri}"
  emr_spark_sg_id          = "${module.TF_Module_VPC.vpc_common_sg_id}"
  emr_spark_config_file    = "${var.emr_spark_config_file}"
  emr_spark_bootstrap_path = "${var.emr_spark_bootstrap_path}"

}
```

-----
## Module Output Variables
- `emr_private_master_sg_id` - EMR Private Master security group ID.
