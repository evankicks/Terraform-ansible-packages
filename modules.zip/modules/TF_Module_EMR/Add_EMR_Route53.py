#!/usr/bin/env python

import sys, getopt
import os, json
import boto3

from botocore.exceptions import ClientError

def main():

    AWS_Region = os.environ['AWS_Region']
    EMR_Cluster_ID = os.environ['EMR_Cluster_ID']
    Route53_Hosted_Zone = os.environ['Route53_Hosted_Zone']

    print("Environment Variables")
    print("    Region is set to '%s'" % AWS_Region)
    print("    EMR Cluster is set to '%s'" % EMR_Cluster_ID)
    print("    Will update entries in Route53 '%s'" % Route53_Hosted_Zone)

    client = boto3.client('emr', region_name=AWS_Region)

    try:
        response = client.list_instances(
            ClusterId=EMR_Cluster_ID,
            InstanceStates=['AWAITING_FULFILLMENT',
                            'PROVISIONING',
                            'BOOTSTRAPPING',
                            'RUNNING']
        )
        ec2_instance_type = dict()
        for instanceId in response['Instances']:
            #print(instanceId['Ec2InstanceId'])
            # With instance ID, this script needs to do
            # 1 Update the instance name tag.
            # 2 Create a route53 entry with that instance's public DNS.
            ec2_resource = boto3.resource('ec2', region_name=AWS_Region)
            ec2_instance = ec2_resource.Instance(instanceId['Ec2InstanceId'])

            # Find and replace the Name tag.
            for tag in ec2_instance.tags:
                if tag['Key'] == "Name":
                    ec2_tag_name_orig = tag['Value']
                    ec2_tag_name = tag['Value'].lower()
                    ec2_tag_name_base = ec2_tag_name.split(" ")[0]
                if tag['Key'] == "aws:elasticmapreduce:instance-group-role":
                    ec2_tag_group_role = tag['Value'].lower()
            index = "%s %s" % (ec2_tag_name_base, ec2_tag_group_role)

            # Increment a count of instance names.
            if index not in ec2_instance_type:
                ec2_instance_type[index] = 0
            ec2_instance_type[index] += 1

            # Preview the revised name tag.
            ec2_tag_name_revised = "%s %s %d" % (ec2_tag_name_base, ec2_tag_group_role, ec2_instance_type[index])
            print("%s: %s" % (ec2_instance.instance_id, ec2_tag_name_revised))

            # Update the name tag as needed.
            if ec2_tag_name_orig != ec2_tag_name_revised :
                del_resp = ec2_instance.delete_tags(
                    DryRun=False,
                    Tags=[
                        {
                            'Key':'Name'
                        }
                    ]
                )
                print("    %s" % del_resp)
                add_resp = ec2_instance.create_tags(
                    DryRun=False,
                    Tags=[
                        {
                            'Key':'Name',
                            'Value':ec2_tag_name_revised
                        }
                    ]
                )
                print("    %s" % add_resp)
            else:
                print("    No change.")

            # Now to update Route53 tables.
            route53_address = ec2_tag_name_revised.replace(" ","-")
            route53_client = boto3.client('route53', region_name=AWS_Region)
            route53_domain = route53_client.get_hosted_zone(Id=Route53_Hosted_Zone)
            route53_address += "."+route53_domain['HostedZone']['Name']
            print("Route53 address: %s" % route53_address)
            print("Instance DNS: %s" % ec2_instance.private_dns_name)

            route53_response = route53_client.change_resource_record_sets(
                HostedZoneId=Route53_Hosted_Zone,
                ChangeBatch={
                    'Comment': 'Added by Add_EMR_Route53.py and Terraform',
                    'Changes': [
                        {
                            'Action': 'UPSERT',
                            'ResourceRecordSet': {
                                'Name': route53_address,
                                'Type': 'CNAME',
                                'TTL': 300,
                                'ResourceRecords': [
                                    {
                                        'Value': ec2_instance.private_dns_name,
                                    },
                                ]
                            }
                        },
                    ]
                }
            )
    except ClientError as e:
        print("Received error: %s" % e)

if __name__ == "__main__":
    main()
