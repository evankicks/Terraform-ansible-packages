## 1.4.0 (January 9, 2019)
BUG FIXES: 
  * Fixed the aws_profile variable. Renamed to emr_aws_profile and updated in README.
  
## 1.3.0 (January 3, 2019)
NEW FEATURES:
  * Opened ports 16010 and 16030 from bastion host to EMR clusters.
  * Added required variable emr_bastion_sg_id.
  
## 1.2.0 (December 14, 2018)
NEW FEATURES:
  * Setting the termination protection as a variable in emr hbase and emr spark.
  
## 1.1.1 (November 21, 2018)
BUG FIXES:
 - Added elk_account_id to allow the kms_key policy to move between account, making this module more universal.

## 1.1.0 (October 19, 2018)
NEW FEATURES:
  * Added a python script and null resource to create route53 entries in a private hosted zone.
  * Python script for route53 entries will update the name tags for each EMR instance.

## 1.0.0 (August 21, 2018)

## 0.0.1 (August 21, 2018)
NEW FEATURES:
IMPROVEMENTS:
BUG FIXES:
