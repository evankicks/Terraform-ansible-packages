Elasticache-Redis Terraform Module
===================

A Terraform Module to deploy a simple Elasticache-Redis into VPC, part of KP GetWell.

This is made to be re-used by other services that may need internal Redis cache server without backup, snapshot, and replication.

Note: this module doesn't provide parameter group.

Refer to `architecture.png` for a diagram of the infrastructure that this module provides.

Architecture
------------
![](architecture.png)

Module Input Variables
----------------------
- `env` - Short code that identifies the environment
- `service` - component or service name
- `env_prefix` - (Optional) Additional prefix name to identify the environment
- `vpc_id` - VPC ID for the security group; subnets_private MUST also be associated with same vpc
- `vpc_cidr_block` - CIDR Block of VPC that match vpc_id
- `azs` - List of availability zones that the ELB will be associated with
- `tag_env` - The full enviornment name used in tagging (lowercase)
- `tag_primvary_owner` - Primvary owner
- `tag_second_owner` - Second owner
- `tag_project` - Used by SRCA techops to monitor other Samsung projects
- `tag_timeframe` - default is 24x7
- `tag_configured` - Denotes the method this resource was provisioned
- `cluster_name` - (Required) Elasticache-Redis Name
- `subnets` - (Required) List of private subnets where cache server resided
- `redis_family` - Redis release version; default is redis3.2
- `instance_type` - cache server instacne type; please read support type:
                     https://aws.amazon.com/elasticache/details/#Available_Cache_Node_Types
- `port` - Redis cache server listening port; default is 6379
- `nodes_qty` - Number of Redis server to create
- `subscriber_sg` - A list of security group which subscribers are allowed to connect
- `parameter_group_name` - Define parameters for Redis server; default is default.redis3.2
- `redis_internal_hosted_zone_id` - The Route53 private hosted zone to give a DNS name for the redis cache nodes. Default: `""`



Available Outputs
----------------

- Elasticache-Redis
- Elasticache Cluster
    - `elasticache_cluster_id` - Elasticache-Redis Name
    - `elasticache_node_ids` - Cache server instance ids
    - `elasticache_node_addresses` - Cache Server instance addresses
    - `elasticache_node_port` - Cache server listening port
    - `elasticache_node_azs` - Cache server availability zones
  Elasticache Subnet Group
    - `elasticache_subnet_group_name` - elasticache subnet group name
    - `elasticache_subnet_group_desc` - subnet group description
    - `elasticache_subnet_group_subnets` - Cache server subnet ids
- Security group
    - `elasticache_security_group_id` - Security Group Id
    - `elasticache_security_group_name` - Security Group Name
    - `elasticache_security_group_vpc_id` - Security Group VPC ID
