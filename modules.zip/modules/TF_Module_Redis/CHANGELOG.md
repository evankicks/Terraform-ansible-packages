## 1.1.0 (November 29, 2018)
NEW FEATURES:
 - Added route53 entries for the redis cache nodes.

## 1.0.0 (August 21, 2018)

## 0.0.1 (August 21, 2018)
NEW FEATURES:
IMPROVEMENTS:
BUG FIXES:
