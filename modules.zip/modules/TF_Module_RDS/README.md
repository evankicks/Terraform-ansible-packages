# RDS Stack

### Description
A Terraform module to create an MySQL RDS instance with security groups and Route53 entries.

-----
## Module Input Variables

- `project` - The project tag for RDS. Default: N/A
- `region` - The AWS region for this environment stack. Default: N/A
- `env_short` - The short version of the environment name. Default: N/A
- `rds_vpc_id` - The VPC ID where the RDS reside. Default: N/A
- `rds_vpc_common_sg_id` - The common security group ID. Default: N/A
- `rds_vpc_bastion_sg_id` - The bastion security group ID. Default: N/A
- `rds_vpc_internal_zone_id` - The internal route53 hosted zone. Default: N/A
- `rds_crp_was_sg_id` - The WAS security group ID. Default: N/A
- `rds_vpc_private_subnet_ids` - The private subnet IDs where this RDS will reside. Default: N/A
- `rds_instance_class` - The RDS instance class. Default: `db.t2.medium`
- `rds_monitoring_interval` - The number of seconds between data points. Default: `30`
- `rds_db_name` - The name of automatically create database. Default: N/A
- `rds_username` - The username for the master DB user. Default: N/A
- `rds_password` - The password for the master DB user. Default: N/A
- `rds_retention_period` - The number of days to retain backups for. Default: `35`
- `rds_tag_sec_assets_gateway` - The gateway tag for this RDS cluster. Default: N/A
- `rds_tag_sec_assets` - The SEC Assets tag for this RDS cluster. Default: N/A
- `rds_sg_tag_sec_gw` - Tags for RDS Security Group. Default: N/A
- `rds_sg_tag_sec_ect` - Tags for RDS Security Group. Default: N/A
- `rds_port` - The RDS Port to use. Default: `43306`
- `rds_availabilityzones` - A list of RDS Availability Zone(s). Default: N/A
- `storage_encrypted` - The storage encryption setting for RDS. Default: `true`
- `performance_insights_enabled` - The performance insights switch to enable or disable. Default: `false`
- `rds_snapshot_identifier` - The name or ARN of a cluster snapshot to use when creating. Default: `""`
- `rds_bastion_ssh_port` - The port number for SSH communications from bastion. Default: `22`

-----
## Usage
```hcl-terraform
module "TF_Module_RDS" {
  #source = "git::https://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_RDS"

  project                    = "${var.project}"
  region                     = "${var.aws_region}"
  env_short                  = "${var.environment_short}"
  rds_vpc_id                 = "${module.TF_Module_VPC.vpc_id}"
  rds_vpc_common_sg_id       = "${module.TF_Module_VPC.}"
  rds_vpc_bastion_sg_id      = "${module.TF_Module_Bastion.bastion_sg_id}"
  rds_vpc_internal_zone_id   = "${module.TF_Module_VPC.vpc_internal_zone_id}"
  rds_crp_was_sg_id          = "${module.TF_Module_CRP.crp_was_sg_id}"
  rds_vpc_private_subnet_ids = ["${module.TF_Module_VPC.vpc_public_subnet_ids}"]
  rds_db_name                = "${var.rds_db_name}"
  rds_username               = "${var.rds-username}"
  rds_password               = "${var.rds_password}"
}
```

## Reloading snapshot


```hcl-terraform
# Get latest snapshot from production DB
#https://medium.com/@vankhoa011/how-i-use-terraform-to-restore-the-latest-snapshot-from-productions-db-to-staging-s-db-aws-rds-6ad4f6620df2
data "aws_db_snapshot" "db_snapshot" {
    most_recent = true
    db_instance_identifier = "db-prod"
}
```

-----
## Module Output Variables
- `name`              - Database name
- `user`              - Username for the master DB user
- `password`          - Password for the master DB user
- `cluster_name`      - Cluster Identifier
- `endpoint`          - The DNS address of the RDS instance
- `reader_endpoint`   - A read-only endpoint for the Aurora cluster, automatically load-balanced across replicas.
- `snapshotRetention` - The number of days that snapshots will be retain.
- `sg_rds_id`         - RDS Security Group ID.
- `sg_rds_name`       - RDS Security Group Name.

-----
## Deployment instructions.
 Stack for deploying a MySQL RDS instance:

- RDS instance
- Security Group

rm -rf .terraform
terraform init --backend-config=env/qa-us-west-2.backend.tfvars
terraform plan  --var-file=env/qa-us-west-2.tfvars
terraform apply  --var-file=env/qa-us-west-2.tfvars
<br/>


## Dependencies  
This stack is dependent on the following Terraform remote states:  

- VPC - https://git.sec.samsung.net/gw-shealth-terraform/vpc
- CRP - https://git.sec.samsung.net/gw-shealth-terraform/crp
