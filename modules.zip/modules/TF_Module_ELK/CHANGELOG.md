## 1.3.1 (December 17, 2018)
IMPROVEMENTS:
 - Locking down TF_Module_EC2 to version v2_3.
 
## 1.3.0 (December 5, 2018)
BUG FIXES: 
 - Added elk_private_cidr for opening logstash to different cidr.
 
## 1.2.0 (November 21, 2018) 
BUG FIXES:
 - Added elk_account_id to allow the kms_key policy to move between account, making this module more universal.
## 1.1.1 (October 3, 2018)
NEW FEATURES:
 - Added boolean operators for turning on or off port 80 and 443 in the ALB.
 
## 1.1.0 (October 3, 2018)
NEW FEATURES:
 - Replaced the ELB with an ALB.
 - Added adjustable CIDR block ranges to permit access to the ALB.


## 1.0.0 (September 26, 2018)
Released to Preprod.

## 0.0.1 (August 21, 2018)
NEW FEATURES:
IMPROVEMENTS:
BUG FIXES:
