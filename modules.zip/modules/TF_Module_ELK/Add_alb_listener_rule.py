#!/usr/bin/env python

import sys, getopt
import os
import boto3
from botocore.exceptions import ClientError

def main():

    AWS_Region = os.environ['AWS_Region']
    ListenerArn = os.environ['ListenerArn'].strip()
    UserPoolArn = os.environ['UserPoolArn'].strip()
    UserPoolClientId = os.environ['UserPoolClientId'].strip()
    UserPoolDomain = os.environ['UserPoolDomain'].strip()
    TargetGroupArn = os.environ['TargetGroupArn'].strip()
    HostPattern = os.environ['HostPattern'].strip()

    print("'"+AWS_Region+"'")
    print("'"+ListenerArn+"'")
    print("'"+UserPoolArn+"'")
    print("'"+UserPoolClientId+"'")
    print("'"+UserPoolDomain+"'")
    print("'"+TargetGroupArn+"'")
    print("'"+HostPattern+"'")

    #client = boto3.setup_default_session(region_name=AWS_Region)
    client = boto3.client('elbv2', region_name=AWS_Region)

    try:
        response = client.create_rule(
            ListenerArn= ListenerArn,
            Conditions=[
                {
                    "Field": "host-header",
                    "Values": [ HostPattern ]
                },
            ],
            Priority=10,
            Actions=[
                {
                    "Type": "authenticate-cognito",
                    "AuthenticateCognitoConfig": {
                        "UserPoolArn": UserPoolArn,
                        "UserPoolClientId": UserPoolClientId,
                        "UserPoolDomain": UserPoolDomain,
                        "SessionCookieName": "AWSELBAuthSessionCookie",
                        "SessionTimeout": 3600,
                        "Scope": "openid",
                        "OnUnauthenticatedRequest": "authenticate"
                    },
                    "Order": 1
                },
                {
                    "Type": "forward",
                    "TargetGroupArn": TargetGroupArn,
                    "Order": 2
                }
            ]
        )

        print("ALB Listener Rule response: ", response)
    except ClientError as e:
        print("Received error: %s" % e)

if __name__ == "__main__":

    main()
    #main(sys.argv[1:])
