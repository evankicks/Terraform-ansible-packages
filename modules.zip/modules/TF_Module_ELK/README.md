# TF_Module_ELK
pip install boto3

### Description
A Terraform module to create the ELK instance with an ELB.

-----
## Module Input Variables

- `elk_vpc_id` - The VPC ID for ELK Instances and ELB. Default: N/A
- `elk_account_id` - The AWS Account ID, used in kms key policy. Default: 060671536724
- `elk_vpc_region` - The VPC Region for the ELK Instances and ELB. Default: N/A
- `elk_ec2_subnet_ids` - The private subnet for the EC2 instances. Default: N/A
- `elk_elb_subnet_ids` - The public subnet for the EC2 instances. Default: N/A
- `elk_private_cidr` - The CIDR range for ELK security group access from private VPC instances. Default: N/A
- `elk_vpc_zone_aliases` - The zone aliases for the ELK VPC. Default: N/A
- `elk_common_sg_id` - The common security group created for ssh access. Default: N/A
- `elk_ami` - The AMI ID for ELK EC2 instances. Default: `ami-3a4b5a5a`
- `elk_instance_count` - The number of elk servers to create. Default: `1`
- `elk_instance_type` - The EC2 instance type for ELK. Default: `m4.2xlarge`
- `elk_keypair` - The EC2 Keypair value. Default: N/A
- `elk_user_data` - The User data for the ELK instances. Default: N/A
- `elk_project` - The project tag for ELK. Default: `kpgw`
- `elk_environment` - The environment tag for ELK. Default: N/A
- `elk_primary_owner` - The primary owner tag for ELK. Default: `ralf.pieper`
- `elk_secondary_owner` - The secondary owner tag for ELK. Default: `ralf.pieper`
- `elk_ec2_service` - The service tag for ELK EC2 instances. Default: `crp`
- `elk_ec2_role` - The role tag for ELK EC2 instances. Default: `elk`
- `elk_elb_service` - The service tag for ELK ELB service. Default: `crp-elk`
- `elk_elb_role` - The role tag for ELK ELB service. Default: `web`
- `elk_elb_logs_bucket_name` - An S3 bucket where the access log is stored. Default: N/A
- `elk_elb_logs_bucket_prefix` - An S3 bucket prefix for the ELK ELB access logs. Default: `elk-elb`
- `elk_elb_logs_interval` - The publishing interval in minutes for ELK ELB. Default: `5`
- `elk_elb_port` - The port number to use for ELK ELB. Default: `5601`
- `elk_elb_cert_iam_id` - The SSL certificate for ELK ELB. Default: N/A
- `elk_elb_health_check` - The target of the ELB Health Check. Default: `/app/kibana`
- `elk_elb_health_check_protocol` - The health check protocol for the ELB. Default: `HTTP`
- `elk_elb_healthy_threshold` - The number of checks before the instance is declared healthy. Default: `3`
- `elk_elb_unhealthy_threshold` - The number of checks before the instances is declared unhealthy. Default: `2`
- `elk_elb_health_check_timeout` - The length of time before the health check times out. Default: `5`
- `elk_timeframe` - The timeframe tag for ELK ELB. Default: `7X24`
- `elk_port80_cidr_block` - The list of cidr blocks for port 80. Default: N/A
- `elk_port443_cidr_block` - The list of cidr blocks for port 443. Default: N/A
- `elk_port80_boolean` - A boolean, 1 or 0, to turn on or off the port80 listener. Default: `1`
- `elk_port443_boolean` - A boolean, 1 or 0, to turn on or off the port443 listener. Default: `1`
- `elk_cognito_host_pattern` - The host pattern to use for elk cognito. Default: N/A

-----
## Usage
```
module "TF_Module_ELK" {
  source = "git::ssh://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_ELK"

  elk_vpc_id           = "${module.TF_Module_VPC.vpc_id}"
  elk_vpc_region       = "${module.TF_Module_VPC.vpc_region}"
  elk_ec2_subnet_ids   = "${module.TF_Module_VPC.vpc_private_subnet_ids}"
  elk_elb_subnet_ids   = "${module.TF_Module_VPC.vpc_public_subnet_ids}"
  elk_vpc_zone_aliases = "${module.TF_Module_VPC.vpc_zone_aliases}"
  elk_common_sg_id     = "${module.TF_Module_VPC.vpc_common_sg_id}"
  elk_keypair          = "${var.elk_keypair}"
  elk_user_data        = "${var.elk_user_data}"

  elk_project     = "${var.project}"
  elk_environment = "${var.environment}"

  elk_elb_logs_bucket_name = "${join("-",list(var.project,var.environment))}"
  elk_elb_cert_iam_id      = "${var.elk_elb_cert_iam_id}"

}
```

-----
## Module Output Variables
- `crp_elk_sg_id` - The ID of the ELK Security Group.
- `crp_elk_sg_name` - The Name of the ELK Security Group.
