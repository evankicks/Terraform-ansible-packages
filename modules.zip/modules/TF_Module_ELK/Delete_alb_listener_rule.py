#!/usr/bin/env python

import sys, getopt
import os
import boto3
import json
from botocore.exceptions import ClientError

def main():

    AWS_Region = os.environ['AWS_Region']
    ListenerArn = os.environ['ListenerArn'].strip()

    print("'"+AWS_Region+"'")
    print("'"+ListenerArn+"'")

    #client = boto3.setup_default_session(region_name=AWS_Region)
    client = boto3.client('elbv2', region_name=AWS_Region)

    try:
        response = client.describe_rules(
            ListenerArn= ListenerArn

        )

        #print("ALB Listener Rule response: ", response)
        #print(json.dumps(response, indent=4, sort_keys=True))
        CognitoRuleArn = ""
        for Rule in response['Rules']:
            for Action in Rule['Actions']:
                if Action['Type'] == 'authenticate-cognito':
                    CognitoRuleArn = Rule['RuleArn']

        print("ALB Listener Rule: ", CognitoRuleArn)
        if CognitoRuleArn != "":
            response = client.delete_rule( RuleArn=CognitoRuleArn )
            print("ALB Listener Rule deleted: ", response)
    except ClientError as e:
        print("Received error: %s" % e)

if __name__ == "__main__":

    main()
    #main(sys.argv[1:])
