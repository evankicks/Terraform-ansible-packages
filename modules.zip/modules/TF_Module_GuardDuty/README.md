# TF_Module_GuardDuty

### Description
A Terraform module to enable GuardDuty and define it with a threat intel set.

-----
## Module Input Variables
- `guardduty_publishing_frequency` - The frequency of publishing for subsequent notifications. Default: `SIX_HOUR`
- `guardduty_threatIntelSet_name` - A list of names for threat intel sets. Default: N/A
- `guardduty_threatIntelSet_bucket` - A list of s3 bucket names for threat intel sets. Default: N/A
- `guardduty_threatIntelSet_key` - A list of s3 bucket key name for threat intel sets. Should match to the bucket listed in guardduty_threatIntelSet_bucket. Default: N/A

-----
## Usage
```
module "TF_Module_GuardDuty" {
  source = "git::https://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_GuardDuty"

  guardduty_threatIntelSet_name   = ["${var.guardduty_threatIntelSet_name}"]
  guardduty_threatIntelSet_bucket = ["${var.guardduty_threatIntelSet_bucket}"]
  guardduty_threatIntelSet_key    = ["${var.guardduty_threatIntelSet_key}"]
}
```

-----
## Module Output Variables
