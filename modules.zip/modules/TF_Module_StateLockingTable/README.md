# TF_Module_StateLockingTable

### Description
Creates a Terraform state locking table using DynamoDB.

-----
## Module Input Variables

- `table_name`        - The name of DynamoDB table. Default: N/A
- `table_environment` - The environment tag for the DynamoDB table. Default: N/A

-----
## Usage
```
module "" {
  source = "git::https://git-codecommit.us-east-1.amazonaws.com/v1/repos/TF_Module_StateLockingTable"

  table_name        = "${var.table_name}"
  table_environment = "${var.table_environment}"

}
```

-----
## Module Output Variables
