**Samsung HeartWise(KP) Jenkins Job**

**This project contains various Jenkins Jobs for KP HeartWise in YAML format.**

The primary tool to deploy this configuration is using [Jenkins Job Builder (JJB)](https://docs.openstack.org/infra/jenkins-job-builder/)

Jenkins Job Builder takes simple descriptions of Jenkins jobs in YAML or JSON format and uses them to configure Jenkins. You can keep your job descriptions in human readable text format in a version control system to make changes and auditing easier. It also has a flexible template system, so creating many similarly configured jobs is easy.

**Installation**

`$ pip install --user jenkins-job-builder`

Use **find / -name jenkins-jobs 2> /dev/null** to check the installation path of **jenkins-jobs** . If path seen is not added, please add it to $PATH.

**Credentials setup**

You need to also set up your config files with your Jenkins credentials.
- In the root of this repo, copy the file jenkins.example.ini - `cp jenkins.example.ini jenkins.ini`
- open/create `jenkins.ini` in your text edit and replace it.
More Info here: [How to set configuration file?](https://docs.openstack.org/infra/jenkins-job-builder/execution.html#)
- By default JJB looks for config at this location `/etc/jenkins_jobs/jenkins_jobs.ini`
    - USERNAME - Your Jenkins Username
    - PASSWORD - Your Jenkins Password
    - JENKINS_URL - The Full Jenkins URL

**Example usage**

- To test the yaml file
```
jenkins-jobs test x.yaml
```
- To store the output of yaml file after test
```
 jenkins-jobs test -o output test.yaml
```
- To upload jenkins job to Jenkins server
```
jenkins-jobs update x.yml
```

**Some useful information**
- To export the jenkins Job from jenkins server jenkins-cli should be used.
- Download the CLI jar from the jenkins server.
- To check your credentials.
```
java -jar jenkins-cli.jar -s http://105.145.72.60:8080/ who-am-i --username USERNAME --password PASSWORD
```
- To view all jenkins jobs in the server
```
java -jar jenkins-cli.jar -s http://105.145.72.60:8080/ list-jobs --username USERNAME --password PASSWORD
```
- get-job- this will export the job in XML file.

- create-job – this will import the job from XML and will create job in Jenkins.
