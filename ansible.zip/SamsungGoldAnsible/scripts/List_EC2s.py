#!/usr/bin/env python3

import sys, getopt
import os, json
import boto3

from botocore.exceptions import ClientError

def print_usage():
    """
    Print usage statements.
    """
    print("Usage: %s [-h|--help] [-r <aws region>|--region <aws region>]" % (sys.argv[0]))

def main(ARGS):
    """
    Primary function to pull down EC2 information.
    """
    try:
        opts, args = getopt.getopt(ARGS, "hr:", ["help", "region="])
    except getopt.GetoptError as arg_err:
        print(arg_err)
        print_usage()
        sys.exit(2)

    region_supplied = False
    AWS_Region = ""

    if len(args) > 0:
        print("Additional args found:" + " ".join(args))
        print_usage()
        sys.exit(2)


    for opt, arg in opts:
        if opt in ("-h","--help"):
            print_usage()
            sys.exit()
        elif opt in ("-r","--region"):
            AWS_Region = arg
            region_supplied = True

    try:
        if region_supplied == True:
            ec2_client = boto3.client('ec2', region_name=AWS_Region)
        else:
            ec2_client = boto3.client('ec2')

        ec2_list = ec2_client.describe_instances()

        # List the instances
        print("%s  %s  %s  %s  %s" % ("Instance ID".ljust(24),
                                      "Key Pair Name".ljust(25),
                                      "Private IP".ljust(15),
                                      "Public IP".ljust(15),
                                      "Tag:Name"))
        for reservation in ec2_list['Reservations']:
            for instance in reservation['Instances']:
                try:
                    print("%s  %s  %s  %s" % (instance['InstanceId'].ljust(24),
                                              instance['KeyName'].ljust(25),
                                              instance['PrivateIpAddress'].ljust(15),
                                              instance['PublicIpAddress'].ljust(15)),
                          end=' ')
                except KeyError:
                    print("%s  %s  %s  " % (instance['InstanceId'].ljust(24),
                                              instance['KeyName'].ljust(25),
                                              instance['PrivateIpAddress'].ljust(30)),
                          end=' ')
                for tag in instance['Tags']:
                    if tag['Key'] == "Name":
                        print(" \"%s\"" % tag['Value'])

    except ClientError as e:
        print("Received error: %s" % e)

if __name__ == "__main__":
    main(sys.argv[1:])
