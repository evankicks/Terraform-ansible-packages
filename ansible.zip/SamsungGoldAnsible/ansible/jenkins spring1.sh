#!/bin/bash -ex
BUILD_NUMBER=39
export SSH_CONF="-i $HOME/.ssh/uat/kp-getwell-uat-ec2_key-2019_01_21_private.pem -p422 -A -F ~/.ssh/config/ssh_config_kpgw_uat -o StrictHostKeyChecking=no -o ProxyCommand='ssh -F ~/.ssh/config/ssh_config_kpgw_uat -W %h:%p uat_bastion_ec2' -l ec2-user"
export s3Path="s3://kpgw-repo/getwell"
echo UAT
export targets="spring1-crp-uw2a-uat.kp-getwell-internal.uat.com spring2-crp-uw2c-uat.kp-getwell-internal.uat.com"
for host in $targets
do
  echo "$(date) - deploy card $BUILD_NUMBER on $host"
  ssh -i $HOME/.ssh/uat/kp-getwell-uat-ec2_key-2019_01_21_private.pem -p422 -A -F ~/.ssh/config/ssh_config_kpgw_uat -o StrictHostKeyChecking=no -o ProxyCommand='ssh -F ~/.ssh/config/ssh_config_kpgw_uat -W %h:%p uat_bastion_ec2' -l ec2-user $host "set -x;
      sudo pkill -f getwell-service-server-1.0.jar;"
  ssh -i $HOME/.ssh/uat/kp-getwell-uat-ec2_key-2019_01_21_private.pem -p422 -A -F ~/.ssh/config/ssh_config_kpgw_uat -o StrictHostKeyChecking=no -o ProxyCommand='ssh -F ~/.ssh/config/ssh_config_kpgw_uat -W %h:%p uat_bastion_ec2' -l ec2-user $host "set -x;
      test -d /opt/getwell/ || sudo mkdir --mode=755 /opt/getwell/;
      test -d /log/spring/ || sudo mkdir --mode=777 /var/log/spring/ ;
      sudo aws s3 cp $s3Path/stg/$BUILD_NUMBER/server/ /opt/getwell/ --recursive "
  ssh -i $HOME/.ssh/uat/kp-getwell-uat-ec2_key-2019_01_21_private.pem -p422 -A -F ~/.ssh/config/ssh_config_kpgw_uat -o StrictHostKeyChecking=no -o ProxyCommand='ssh -F ~/.ssh/config/ssh_config_kpgw_uat -W %h:%p uat_bastion_ec2' -l ec2-user $host "sudo java -jar /opt/getwell/getwell-service-server-1.0.jar --spring.config.location=file:/opt/getwell/config/application.properties > /dev/null &"
  sleep 60
  ssh -i $HOME/.ssh/uat/kp-getwell-uat-ec2_key-2019_01_21_private.pem -p422 -A -F ~/.ssh/config/ssh_config_kpgw_uat -o StrictHostKeyChecking=no -o ProxyCommand='ssh -F ~/.ssh/config/ssh_config_kpgw_uat -W %h:%p uat_bastion_ec2' -l ec2-user $SSH_CONF $host "sh /opt/getwell/config/authenticate.sh"
done
# end
exit

failfailfailfailhere

ssh -A -o StrictHostKeyChecking=no -o 'ProxyCommand=ssh -W %h:%p -F ~/.ssh/config/ssh_config_kpgw_uat uat_bastion_ec2' ec2-user@spring2-crp-uw2c-uat.kp-getwell-internal.uat.com -i ~/.ssh/uat/kp-getwell-uat-ec2_key-2019_01_21_private.pem -p422

#Example: GETWELL_SPRING_APP_DEPLOY_STG
#!/bin/bash -x
export SSH_CONF=~/.ssh/config/ssh_config_kpgw_stg
export s3Path="s3://kpgw-repo/getwell"
echo STG
export targets="spring1-kp-uw1a-stg spring2-kp-uw1c-stg"
for host in $targets
do
  echo "$(date) - deploy card $BUILD_NUMBER on $host"
  ssh -l secuser -A -F $SSH_CONF $host "sudo pkill -f getwell-service-server-1.0.jar"
  ssh -l secuser -A -F $SSH_CONF $host " test -d /opt/getwell/ || sudo mkdir --mode=755 /opt/getwell/ "
  ssh -l secuser -A -F $SSH_CONF $host " test -d /var/log/spring/ || sudo mkdir --mode=777 /var/log/spring/ "
  ssh -l secuser -A -F $SSH_CONF $host "sudo aws s3 cp $s3Path/stg/$BUILD_NUMBER/server/ /opt/getwell/ --recursive"
  ssh -l secuser -A -F $SSH_CONF $host "sudo java -jar /opt/getwell/getwell-service-server-1.0.jar --spring.config.location=file:/opt/getwell/config/application.properties > /dev/null &"
  sleep 60
  ssh -l secuser -A -F $SSH_CONF $host "sh /opt/getwell/config/authenticate.sh"
done

#~/.ssh/config/ssh_config_kpgw_stg

.ssh/config
Host=uat_bastion_ec2
	HostName=52.32.12.39
	Port=422
	User=ec2-user
	IdentityFile=~/.ssh/uat/kp-getwell-uat-ec2_key-2019_01_21_private.pem
	ForwardAgent=yes
	AddKeysToAgent=yes

Host=10.192.*
  User=ec2-user
	Port=422
  IdentityFile=~/.ssh/uat/kp-getwell-uat-ec2_key-2019_01_21_private.pem
  ProxyCommand ssh -W %h:%p  ec2-user@uat_bastion_ec2
