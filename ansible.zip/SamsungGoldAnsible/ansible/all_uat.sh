set -xe
#elk
ansible-playbook elk/elk_uat.yml -i server_health/hosts_uat # https://aws.amazon.com/blogs/security/how-to-restrict-amazon-s3-bucket-access-to-a-specific-iam-role/
ansible-playbook elk/elk-client_uat.yml -i server_health/hosts_uat
ansible-playbook springboot/springboot.yml -i server_health/hosts_uat
ansible-playbook emr/emr.yml -i emr/hosts_uat

ansible-playbook server_health/awslogs.yml -i server_health/hosts_uat
ansible-playbook server_health/cloudwatch_agent.yml -i server_health/hosts_uat
ansible-playbook server_health/cloudwatch_monitor.yml -i server_health/hosts_uat
ansible-playbook server_health/log_management.yml -i server_health/hosts_uat
ansible-playbook server_health/process_check.yml -i server_health/hosts_uat
ansible-playbook server_health/user_add.yml -i server_health/hosts_uat
#zeppelin
#security
