# This script first moves snapshots from a folder into the Hbase app.
# Then, these snapshots are loaded into the current folder.
# NOTE: Make sure that all tables are already defined in Phoenix before running this script
#       (otherwise, serialization errors might occur)

echo "Starting import-loading script"

SRC_SCHEMA='KPREHAB_002'
DEST_SCHEMA='KPREHAB_002'

SRC_ARCHIVE_AUTHSERVER_SCHEMA='ARCHIVE_AUTHSERVER'
DEST_ARCHIVE_AUTHSERVER_SCHEMA='ARCHIVE_AUTHSERVER'

SRC_ARCHIVE_KPREHAB_SCHEMA='ARCHIVE_KPREHAB_SCHEMA'
DEST_ARCHIVE_KPREHAB_SCHEMA='ARCHIVE_KPREHAB_SCHEMA'

# Tables
TABLES=''
TABLES+='ACTIVITY '
TABLES+='APPINFO '
TABLES+='APPOINTMENT '
TABLES+='BUDDIES '
TABLES+='CARECALENDAR '
TABLES+='CAREPLAN '
TABLES+='CASEMANAGER '
TABLES+='COMPLIANCE_EXERCISE '
TABLES+='COMPLIANCE_MEDICATION '
TABLES+='COMPLIANCE_READING '
TABLES+='DEVICEINFO '
TABLES+='ENROLLMENT '
TABLES+='EVENTS '
TABLES+='FEEDBACK '
TABLES+='HEALTHHISTORY '
TABLES+='MEDICALCENTERS '
TABLES+='PUSH_HISTORY '
TABLES+='PUSH_LOG '
TABLES+='QUIZZES '
TABLES+='READINGFEEDBACK '
TABLES+='READINGS '
TABLES+='REMINDERS '
TABLES+='STATS_DAILY '
TABLES+='SURVEYS '
TABLES+='TIPS '
TABLES+='USERINFO '
TABLES+='WEARABLEINFO '
TABLES+='TERMS '
TABLES+='USER_TERMS_HISTORY '

# ARCHIVE_AUTHSERVER Tables
ARCHIVE_AUTHSERVER_TABLES=''
ARCHIVE_AUTHSERVER_TABLES+='ACCESS_TOKEN '
ARCHIVE_AUTHSERVER_TABLES+='ACCOUNT '
ARCHIVE_AUTHSERVER_TABLES+='REHAB_ACCOUNT '
ARCHIVE_AUTHSERVER_TABLES+='REHAB_TRIAL_ACCESS_TOKEN '

# ARCHIVE_KPREHAB Tables
ARCHIVE_KPREHAB_TABLES=''
ARCHIVE_KPREHAB_TABLES+='ACTIVITY '
ARCHIVE_KPREHAB_TABLES+='APPOINTMENT '
ARCHIVE_KPREHAB_TABLES+='BUDDIES '
ARCHIVE_KPREHAB_TABLES+='CARECALENDAR '
ARCHIVE_KPREHAB_TABLES+='CAREPLAN '
ARCHIVE_KPREHAB_TABLES+='COMPLIANCE_EXERCISE '
ARCHIVE_KPREHAB_TABLES+='COMPLIANCE_MEDICATION '
ARCHIVE_KPREHAB_TABLES+='COMPLIANCE_READING '
ARCHIVE_KPREHAB_TABLES+='DEVICEINFO '
ARCHIVE_KPREHAB_TABLES+='ENROLLMENT '
ARCHIVE_KPREHAB_TABLES+='EVENTS '
ARCHIVE_KPREHAB_TABLES+='FEEDBACK '
ARCHIVE_KPREHAB_TABLES+='HEALTHHISTORY '
ARCHIVE_KPREHAB_TABLES+='PUSH_LOG '
ARCHIVE_KPREHAB_TABLES+='QUIZZES '
ARCHIVE_KPREHAB_TABLES+='READINGFEEDBACK '
ARCHIVE_KPREHAB_TABLES+='REMINDERS '
ARCHIVE_KPREHAB_TABLES+='STATS_DAILY '
ARCHIVE_KPREHAB_TABLES+='SURVEYS '
ARCHIVE_KPREHAB_TABLES+='USERINFO '
ARCHIVE_KPREHAB_TABLES+='USER_TERMS_HISTORY '
ARCHIVE_KPREHAB_TABLES+='WEARABLEINFO '


# Param
SNPSHT='SNPSHT'

# Use latest date
DT=$(HADOOP_USER_NAME=hbase hadoop fs -ls /user/hbase/repl/ | grep -o "[0-9]\{14\}_${SNPSHT}" | sort -r | head -1| grep -o '[0-9]\{14\}')
echo "Latest date: ${DT}"

# Dirs
BASE_DIR="/user/hbase/repl/${DT}_${SNPSHT}/"
SNPSHT_DIR='.hbase-snapshot/'
ARCH_DIR='archive/data/default/'
HBASE_DIR='/apps/hbase/data/'

hdfs dfs -mkdir ${HBASE_DIR}${SNPSHT_DIR}
echo "mkdir ${HBASE_DIR}${SNPSHT_DIR}"

hdfs dfs -mkdir ${HBASE_DIR}${ARCH_DIR}
echo "mkdir ${HBASE_DIR}${ARCH_DIR}"

echo "Source schema: ${SRC_SCHEMA}"
echo "Destination schema: ${DEST_SCHEMA}"
echo "Tables: ${TABLES}"
echo "Base dir: ${BASE_DIR}"
echo "Hbase dir: ${HBASE_DIR}"

# Check if basedir exists
HADOOP_USER_NAME=hbase hadoop fs -test -d ${BASE_DIR}; dirExists=$?
if [[ ${dirExists} != 0 ]] ; then
        echo 'Base directory does not exist'
        exit 1
fi

# Import and load
for table in $TABLES;
do
        echo "==== Copying files to hbase app for ${table} ===="

        src_table_snpsht=${SRC_SCHEMA}_${table}_${SNPSHT}${DT}
        src_table=${SRC_SCHEMA}.${table}
        dest_table=${DEST_SCHEMA}.${table}
        dtstr=$(date +%s)

        HADOOP_USER_NAME=hbase hadoop fs -test -d ${HBASE_DIR}${SNPSHT_DIR}${src_table_snpsht}; dirExists=$?
        if [[ ${dirExists} == 0 ]] ; then
                echo "Hbase directory already contains snapshot ${src_table_snpsht}"
                echo "Skipping"
                continue
        fi

        HADOOP_USER_NAME=hbase hadoop fs \
        -cp ${BASE_DIR}${SNPSHT_DIR}${src_table_snpsht} ${HBASE_DIR}${SNPSHT_DIR}

        HADOOP_USER_NAME=hbase hadoop fs -rm -r ${HBASE_DIR}${ARCH_DIR}${src_table}

        HADOOP_USER_NAME=hbase hadoop fs \
        -cp ${BASE_DIR}${ARCH_DIR}${src_table} ${HBASE_DIR}${ARCH_DIR}

        echo "==== Loading snapshot for ${table} ===="

        dsbl="disable '${dest_table}'"
        drp="drop '${dest_table}'"
        cln="clone_snapshot '${src_table_snpsht}', '${dest_table}'"
        enbl="enable '${dest_table}'"
        dlt="delete_snapshot '${src_table_snpsht}'"
        echo "${dsbl}; ${drp}; ${cln}; ${enbl}; ${dlt}" | HADOOP_USER_NAME=hbase hbase shell

        dtend=$(date +%s)
        dtdiff=$((dtend-dtstr))
        echo "-- Table ${table} replication complete (${dtdiff} secs.) --"

done

for table in $ARCHIVE_AUTHSERVER_TABLES;
do
        echo "==== Copying files to hbase app for ${table} ===="

        src_table_snpsht=${SRC_ARCHIVE_AUTHSERVER_SCHEMA}_${table}_${SNPSHT}${DT}
        src_table=${SRC_ARCHIVE_AUTHSERVER_SCHEMA}.${table}
        dest_table=${DEST_ARCHIVE_AUTHSERVER_SCHEMA}.${table}
        dtstr=$(date +%s)

        HADOOP_USER_NAME=hbase hadoop fs -test -d ${HBASE_DIR}${SNPSHT_DIR}${src_table_snpsht}; dirExists=$?
        if [[ ${dirExists} == 0 ]] ; then
                echo "Hbase directory already contains snapshot ${src_table_snpsht}"
                echo "Skipping"
                continue
        fi

        HADOOP_USER_NAME=hbase hadoop fs \
        -cp ${BASE_DIR}${SNPSHT_DIR}${src_table_snpsht} ${HBASE_DIR}${SNPSHT_DIR}

        HADOOP_USER_NAME=hbase hadoop fs -rm -r ${HBASE_DIR}${ARCH_DIR}${src_table}

        HADOOP_USER_NAME=hbase hadoop fs \
        -cp ${BASE_DIR}${ARCH_DIR}${src_table} ${HBASE_DIR}${ARCH_DIR}

        echo "==== Loading snapshot for ${table} ===="

        dsbl="disable '${dest_table}'"
        drp="drop '${dest_table}'"
        cln="clone_snapshot '${src_table_snpsht}', '${dest_table}'"
        enbl="enable '${dest_table}'"
        dlt="delete_snapshot '${src_table_snpsht}'"
        echo "${dsbl}; ${drp}; ${cln}; ${enbl}; ${dlt}" | HADOOP_USER_NAME=hbase hbase shell

        dtend=$(date +%s)
        dtdiff=$((dtend-dtstr))
        echo "-- Table ${table} replication complete (${dtdiff} secs.) --"

done

for table in $ARCHIVE_KPREHAB_TABLES;
do
        echo "==== Copying files to hbase app for ${table} ===="

        src_table_snpsht=${SRC_ARCHIVE_KPREHAB_SCHEMA}_${table}_${SNPSHT}${DT}
        src_table=${SRC_ARCHIVE_KPREHAB_SCHEMA}.${table}
        dest_table=${DEST_ARCHIVE_KPREHAB_SCHEMA}.${table}
        dtstr=$(date +%s)

        HADOOP_USER_NAME=hbase hadoop fs -test -d ${HBASE_DIR}${SNPSHT_DIR}${src_table_snpsht}; dirExists=$?
        if [[ ${dirExists} == 0 ]] ; then
                echo "Hbase directory already contains snapshot ${src_table_snpsht}"
                echo "Skipping"
                continue
        fi

        HADOOP_USER_NAME=hbase hadoop fs \
        -cp ${BASE_DIR}${SNPSHT_DIR}${src_table_snpsht} ${HBASE_DIR}${SNPSHT_DIR}

        HADOOP_USER_NAME=hbase hadoop fs -rm -r ${HBASE_DIR}${ARCH_DIR}${src_table}

        HADOOP_USER_NAME=hbase hadoop fs \
        -cp ${BASE_DIR}${ARCH_DIR}${src_table} ${HBASE_DIR}${ARCH_DIR}

        echo "==== Loading snapshot for ${table} ===="

        dsbl="disable '${dest_table}'"
        drp="drop '${dest_table}'"
        cln="clone_snapshot '${src_table_snpsht}', '${dest_table}'"
        enbl="enable '${dest_table}'"
        dlt="delete_snapshot '${src_table_snpsht}'"
        echo "${dsbl}; ${drp}; ${cln}; ${enbl}; ${dlt}" | HADOOP_USER_NAME=hbase hbase shell

        dtend=$(date +%s)
        dtdiff=$((dtend-dtstr))
        echo "-- Table ${table} replication complete (${dtdiff} secs.) --"

done

echo "Ending import-loading script"
