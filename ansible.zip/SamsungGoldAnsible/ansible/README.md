#For new env use all_uat.sh as an Example
Also remember to put ssh_config_uat like config in your .ssh/config to get through the Bastions.

# ELK/EMR/Springboot/Zeppelin as was done in prod_uw2

## For ansible local with proxy through bastion host.
### Verify files.
- elk/group_vars/var_host_<environment>.yml, where environment is the name of the environment.
  - Verify ansible_ssh_common_args statement with the bastion host public dns and key file.
- elk/hosts_<environment>, where environment is the name of the environment.
  - Verify route53 entries and ssh key locations.
- elk/elk_<environment>.yml
  - Verify vars_files match to the group_vars/var_host_<environment>.yml file.
- elk/elk-client_<environment>.yml
  - Verify vars_files match to the group_vars/var_host_<environment>.yml file.
- emr/group_vars/var_bastion.yml
  - Verify ansible_ssh_common_args statement with the bastion host public dns and key file.
- emr/hosts_<environment>
  - Verify route53 entries and ssh key locations.
- springboot/group_vars/var_bastion.yml
  - Verify ansible_ssh_common_args statement with the bastion host public dns (or Route53 address) and key file.
- springboot/hosts_<environment>
  - Verify route53 entries and ssh key locations.
- zeppelin/group_vars/var_bastion.yml
  - Verify ansible_ssh_common_args statement with the bastion host public dns (or Route53 address) and key file.
- zeppelin/group_vars/vars.yml
  - Verify and update with IP address as necessary.
- zeppelin/hosts_prod-uw2
  - Verify route53 entries and ssh key locations.


### Execute Ansible
cd SamsungGoldAnsible/ansible
ansible-playbook springboot/springboot.yml -i server_health/hosts_uat -u ec2-user
ansible-playbook emr/emr.yml -i emr/hosts_uat -u ec2-user

ansible-playbook server_health/awslogs.yml -i server_health/hosts_uat -u ec2-user
ansible-playbook server_health/cloudwatch_agent.yml -i server_health/hosts_uat -u ec2-user
ansible-playbook server_health/cloudwatch_monitor.yml -i server_health/hosts_uat -u ec2-user
ansible-playbook server_health/log_management.yml -i server_health/hosts_uat -u ec2-user
ansible-playbook server_health/process_check.yml -i server_health/hosts_uat -u ec2-user
ansible-playbook server_health/user_add.yml -i server_health/hosts_uat -u ec2-user
#elk
ansible-playbook elk/elk_uat.yml -i server_health/hosts_uat -u ec2-user
# mkdir -p /usr/share/elasticsearch/logs
ansible-playbook elk/elk-client_uat.yml -i server_health/hosts_uat -u ec2-user
#zeppelin
#security

5. ansible-playbook zeppelin/hdp-master.yml -i zeppelin/hosts_<environment> -u ec2-user
6. ansible-playbook zeppelin/hdp-data.yml -i zeppelin/hosts_<environment> -u ec2-user
7. ansible-playbook zeppelin/create-cluster.yml -i zeppelin/hosts_<environment> -u ec2-user
8. Open a browser and log into Zeppelin's Ambari server. Verify that the components install correctly.
8a. SmartSense's "Activity Analysis" password may need to be updated. Go to Services tab. Select SmartSense, then the Configs tab. Under "Activity Analysis", enter a password for user `admin`. Click Save.
9. ansible-playbook zeppelin/zeppelin-setup.yml -i zeppelin/hosts_<environment> -u ec2-user

--------
ansible <host_group> -m setup -i server_health/hosts_<environment> --ssh-common-args='-o StrictHostKeyChecking=no -o ProxyCommand="ssh -W %h:%p -i ~/.ssh/<private key file> ec2-user@<bastion host public dNS>"' --key-file=~/.ssh/<private key file> -u ec2-user

--------

# debugging elk
ssh elk1-crp-uw2a-uat.kp-getwell-internal.uat.com
## show all indexes
curl -XGET 'http://localhost:9200/_cat/indices?v'
## delete one index
curl -XDELETE 'http://localhost:9200/tomcat'
## show logstash.yml without comments
grep '^[[:blank:]]*[^[:blank:]#;]'


# Prior instructions. DO NOT USE.
# ELK

##update SSH connection details for Bastion host if you are not running on the bastion host - otherwise remove the file or rename it to something besides all
- update elk/group_vars/all

## Update vars.yml Files
- update elk/group_vars/vars.yml
- update elk/roles/storage/vars/main.yml

## Setup ELK - (cd into elk folder)
1.  sudo ansible-playbook elk.yml -i hosts_preprod -u ec2-user
2.  sudo ansible-playbook elk-client.yml -i hosts_preprod -u ec2-user

# EMR

## Update hosts_preprod/hosts_prod Files
- update emr/hosts_preprod or emr_hosts_prod

## Setup EMR - (cd into emr folder)
1.  sudo ansible-playbook emr.yml -i hosts_preprod -u ec2-user

# Zeppelin

## Update vars.yml Files
- update zeppelin/group_vars/vars.yml

## Setup Zeppelin - (cd into zeppelin folder)
1.  ANSIBLE_HOST_KEY_CHECKING=False
2.  sudo ansible-playbook hdp-master.yml -i hosts_preprod -u ec2-user
3.  sudo ansible-playbook hdp-data.yml -i hosts_preprod -u ec2-user
4.  sudo ansible-playbook create-cluster.yml -i hosts_preprod -u ec2-user
4a. After run. Log into ambari. Go to Services tab. Select SmartSense, then the Configs tab. Under "Activity Analysis", enter a password for user `admin`. Click Save.
5.  sudo ansible-playbook zeppelin-setup.yml -i hosts_preprod -u ec2-user
